"""استخراج النص: PDF (poppler ثم pypdf ثم OCR للصفحات المصورة) / Word / PowerPoint / TXT / صور (OCR)."""
import os, subprocess, tempfile, unicodedata, glob
import config
def _clean(t): return unicodedata.normalize("NFKC", t or "").replace("\x00", "").strip()
def _ocr_image(path):
    import pytesseract; from PIL import Image
    try: return _clean(pytesseract.image_to_string(Image.open(path), lang=config.OCR_LANGS))
    except pytesseract.TesseractError: return _clean(pytesseract.image_to_string(Image.open(path), lang="eng"))
def _pdf(path):
    pages = []
    try:
        from pypdf import PdfReader; n = len(PdfReader(path).pages)
    except Exception as e: raise ValueError("ملف PDF تالف أو محمي") from e
    for p in range(1, n + 1):
        txt = ""
        try: txt = subprocess.run(["pdftotext","-f",str(p),"-l",str(p),"-layout",path,"-"],capture_output=True,timeout=60).stdout.decode("utf8","ignore")
        except Exception: pass
        if len(txt.strip()) < 15:
            try:
                from pypdf import PdfReader; txt = PdfReader(path).pages[p-1].extract_text() or ""
            except Exception: txt = ""
        if len(txt.strip()) < 15:   # صفحة مصورة → OCR
            with tempfile.TemporaryDirectory() as d:
                try:
                    subprocess.run(["pdftoppm","-r","200","-f",str(p),"-l",str(p),"-png",path,d+"/pg"],timeout=120)
                    imgs = glob.glob(d+"/pg*.png")
                    if imgs: txt = _ocr_image(imgs[0])
                except Exception: pass
        pages.append((p, _clean(txt)))
    return pages
def _docx(path):
    import docx; d = docx.Document(path); out = [p.text for p in d.paragraphs if p.text.strip()]
    for t in d.tables:
        out.append("\n".join(" | ".join(c.text.strip() for c in r.cells) for r in t.rows))
    return [(1, _clean("\n".join(out)))]
def _pptx(path):
    from pptx import Presentation; pages = []
    for i, s in enumerate(Presentation(path).slides, 1):
        out = []
        for sh in s.shapes:
            if sh.has_text_frame: out.append(sh.text_frame.text)
            if getattr(sh, "has_table", False) and sh.has_table:
                out += [" | ".join(c.text for c in r.cells) for r in sh.table.rows]
        pages.append((i, _clean("\n".join(out))))
    return pages
def extract(path, ext):
    ext = ext.lower()
    if ext == "pdf": pages = _pdf(path)
    elif ext == "docx": pages = _docx(path)
    elif ext == "pptx": pages = _pptx(path)
    elif ext == "txt":
        raw = open(path, "rb").read()
        for enc in ("utf-8-sig", "cp1256", "cp1255", "latin-1"):
            try: pages = [(1, _clean(raw.decode(enc)))]; break
            except UnicodeDecodeError: pass
    elif ext in ("png","jpg","jpeg","webp"): pages = [(1, _ocr_image(path))]
    else: raise ValueError("نوع ملف غير مدعوم")
    if not any(t for _, t in pages): raise ValueError("لم يُستخرج أي نص (جرّب ملفًا أوضح أو أضف النص يدويًا)")
    return pages
