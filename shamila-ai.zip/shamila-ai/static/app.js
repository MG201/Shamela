(function(){
'use strict';
var S={csrf:'',user:null,lang:localStorage.getItem('lang')||'ar',subjects:[],recent:[],llm:false,credit:{}};
var T={
 ar:{name:'مساعد الثانوية الشاملة',home:'الرئيسية',hist:'سجل المحادثات',acc:'حسابي',about:'عن المشروع',info:'معلومات التطبيق',hi:'أهلًا بك',sub:'اسأل عن أي درس أضافه معلموك واعتمدوه.',
 search:'ابحث عن مادة…',core:'المواد الدراسية',track:'التخصصات',recent:'آخر المواد المضافة',avail:'متاح',soon:'قريبًا',topics:'موضوعات منشورة',start:'ابدأ المحادثة',send:'إرسال',ph:'اكتب سؤالك…',
 login:'دخول',reg:'إنشاء حساب',user:'اسم المستخدم',pass:'كلمة المرور',nm:'الاسم',gr:'الصف',g10:'العاشر',g11:'الحادي عشر',g12:'الثاني عشر',out:'تسجيل الخروج',newc:'محادثة جديدة',
 src:'المصادر',nocont:'لم يُنشر محتوى لهذه المادة بعد.',units:'الوحدات والموضوعات',all:'كل الموضوعات',needlogin:'سجّل الدخول لبدء المحادثة',empty:'لا توجد محادثات بعد.',del:'حذف',
 abt:'فكرة المشروع: مساعد تعليمي يشرح فقط ما أضافه المعلمون واعتمدوه في قاعدة المحتوى، مع ذكر المصدر ورقم الصفحة.',goals:'الأهداف: دعم طلاب الصفوف العاشر–الثاني عشر، الالتزام الصارم بالمصادر المعتمدة، وإتاحة مراجعة الدروس والتدرب عليها.',
 by:'منشئ المشروع: محمد عبد جبارين — الصف الحادي عشر (ز) — المدرسة الثانوية الشاملة، أم الفحم.',date:'تاريخ الإنشاء: 2026',ocr:'نص من صورة',err:'حدث خطأ، حاول مرة أخرى'},
 he:{name:'עוזר תיכון א-שמילה',home:'ראשי',hist:'היסטוריה',acc:'החשבון שלי',about:'על הפרויקט',info:'מידע על האפליקציה',hi:'ברוך הבא',sub:'שאל על כל שיעור שהמורים הוסיפו ואישרו.',
 search:'חפש מקצוע…',core:'מקצועות',track:'מגמות',recent:'נוסף לאחרונה',avail:'זמין',soon:'בקרוב',topics:'נושאים שפורסמו',start:'התחל שיחה',send:'שלח',ph:'כתוב שאלה…',
 login:'כניסה',reg:'הרשמה',user:'שם משתמש',pass:'סיסמה',nm:'שם',gr:'כיתה',g10:'י׳',g11:'י״א',g12:'י״ב',out:'התנתק',newc:'שיחה חדשה',
 src:'מקורות',nocont:'עדיין לא פורסם תוכן.',units:'יחידות ונושאים',all:'כל הנושאים',needlogin:'התחבר כדי להתחיל',empty:'אין שיחות עדיין.',del:'מחק',
 abt:'רעיון: עוזר לימודי שמסביר רק חומר שהמורים הוסיפו ואישרו, עם מקור ומספר עמוד.',goals:'מטרות: תמיכה בתלמידי י׳–י״ב, הסתמכות על מקורות מאושרים בלבד.',
 by:'יוצר: מוחמד עבד ג׳בארין — כיתה י״א (ז) — תיכון שאמלה, אום אל-פחם.',date:'תאריך יצירה: 2026',ocr:'טקסט מתמונה',err:'אירעה שגיאה'},
 en:{name:'Al-Shamila Study Assistant',home:'Home',hist:'History',acc:'Account',about:'About',info:'App info',hi:'Welcome',sub:'Ask about any lesson your teachers added and approved.',
 search:'Search subjects…',core:'Subjects',track:'Tracks',recent:'Recently added',avail:'Available',soon:'Soon',topics:'published topics',start:'Start chat',send:'Send',ph:'Type your question…',
 login:'Log in',reg:'Sign up',user:'Username',pass:'Password',nm:'Name',gr:'Grade',g10:'10',g11:'11',g12:'12',out:'Log out',newc:'New chat',
 src:'Sources',nocont:'No content published yet.',units:'Units & topics',all:'All topics',needlogin:'Log in to start chatting',empty:'No chats yet.',del:'Delete',
 abt:'Idea: a study assistant that only explains material teachers added and approved, citing file and page.',goals:'Goals: support grades 10–12 and stay strictly within approved sources.',
 by:'Creator: Mohammad Abd Jabbarin — Grade 11 (Z) — Comprehensive Secondary School, Umm Al-Fahm.',date:'Created: 2026',ocr:'Text from image',err:'Something went wrong'}};
var ICON={book:'📘',default:'📘'}, ICONS={'البيولوجيا':'🧬','البيوتكنولوجيا':'🔬','الكيمياء':'⚗️','علوم البيئة':'🌿','الرياضيات':'➗','علم الحاسوب وهندسة البرامج':'💻','علم المعلومات والبيانات':'📊','الهندسة المعمارية':'🏛️','الميكاترونيكا والروبوتيكا':'🤖','اللغة العربية':'✒️','اللغة العبرية':'📖','اللغة الإنجليزية':'🔤','التاريخ':'🏺','المدنيات':'⚖️','التربية الإسلامية':'🕌','التربية البدنية والرياضة':'🏃','التربية الاجتماعية':'🤝','التربية الوطنية':'🏳️'};
function t(k){return (T[S.lang]||T.ar)[k]||T.ar[k]||k}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function $(s,r){return (r||document).querySelector(s)}
function api(path,opt){opt=opt||{};var h={'X-CSRF':S.csrf};if(opt.body&&!(opt.body instanceof FormData)){h['Content-Type']='application/json';opt.body=JSON.stringify(opt.body)}
 return fetch(path,Object.assign({headers:h,credentials:'same-origin'},opt)).then(function(r){return r.json().catch(function(){return{}}).then(function(j){if(!r.ok)throw Object.assign(new Error(j.error||t('err')),{status:r.status});return j})})}
function md(src){ // مُحوِّل Markdown مبسّط وآمن: عناوين، خط عريض، جداول، أكواد، قوائم
 var parts=String(src).split(/```/),out='';
 parts.forEach(function(p,i){ if(i%2){out+='<pre><code>'+esc(p.replace(/^\w*\n/,''))+'</code></pre>';return}
  var lines=p.split('\n'),html='',tbl=[],list=false;
  function flush(){if(tbl.length){html+='<table>'+tbl.map(function(r,ri){var c=r.replace(/^\||\|$/g,'').split('|');return '<tr>'+c.map(function(x){return (ri?'<td>':'<th>')+inl(x.trim())+(ri?'</td>':'</th>')}).join('')+'</tr>'}).join('')+'</table>';tbl=[]}if(list){html+='</ul>';list=false}}
  lines.forEach(function(l){
   if(/^\s*\|?.+\|.+\|?\s*$/.test(l)){if(/^[\s|:\-]+$/.test(l))return;if(list){html+='</ul>';list=false}tbl.push(l);return}
   flush();
   var h=l.match(/^#{1,4}\s+(.*)/); if(h){html+='<h3 dir="auto">'+inl(h[1])+'</h3>';return}
   var li=l.match(/^\s*[-•*]\s+(.*)/); if(li){if(!list){html+='<ul>';list=true}html+='<li>'+inl(li[1])+'</li>';return}
   if(l.trim())html+='<p dir="auto">'+inl(l)+'</p>'});
  flush(); out+=html});
 function inl(s){return esc(s).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/_\((.+?)\)_/g,'<small class="muted">($1)</small>').replace(/`(.+?)`/g,'<code>$1</code>')}
 return out}
function applyLang(){var d=S.lang==='en'?'ltr':'rtl';document.documentElement.lang=S.lang;document.documentElement.dir=d;document.title=t('name');$('#app-title').textContent=t('name');
 var nav=[['#/','🏠',t('home')],['#/history','🕘',t('hist')],['#/account','👤',t('acc')],['#/about','ℹ️',t('about')]];
 $('#bar').innerHTML=nav.map(function(n){return '<a href="'+n[0]+'" data-h="'+n[0]+'"><span>'+n[1]+'</span>'+n[2]+'</a>'}).join('')}
function setBar(){var h=location.hash||'#/';document.querySelectorAll('#bar a').forEach(function(a){a.classList.toggle('on',a.dataset.h===h||(a.dataset.h!=='#/'&&h.indexOf(a.dataset.h)===0))})}
function credit(){return '<div class="credit"><p lang="ar" dir="rtl">'+esc(S.credit.ar)+'</p><p lang="en" dir="ltr">'+esc(S.credit.en)+'</p></div>'}
function card(s){var n=s.topics;return '<button class="subj '+(s.available?'on':'')+'" data-sid="'+s.id+'"><span class="ic">'+(ICONS[s.name]||'📘')+'</span><b>'+esc(s.name)+'</b><small>'+esc(s.description||'')+'</small>'+
 '<span class="badge '+(s.available?'ok':'')+'">'+(s.available?t('avail'):t('soon'))+'</span><small>'+n+' '+t('topics')+'</small></button>'}
function home(){var q='';var v=$('#view');
 function draw(){var f=S.subjects.filter(function(s){return !q||s.name.indexOf(q)>-1});
  $('#lists').innerHTML=['core','track'].map(function(k){var L=f.filter(function(s){return s.kind===k});return L.length?'<h2>'+t(k)+'</h2><div class="grid">'+L.map(card).join('')+'</div>':''}).join('')}
 v.innerHTML='<section class="hello"><h1>'+t('hi')+(S.user?'، '+esc(S.user.name):'')+'</h1><p>'+t('sub')+'</p></section><input id="q" type="search" placeholder="'+t('search')+'" aria-label="'+t('search')+'">'+
  (S.recent.length?'<h2>'+t('recent')+'</h2><div class="srcs">'+S.recent.map(function(r){return '<button class="src" data-sid="'+r.sid+'">'+esc(r.subject)+' · '+esc(r.title)+'</button>'}).join('')+'</div>':'')+'<div id="lists"></div>'+credit();
 draw(); $('#q').oninput=function(e){q=e.target.value.trim();draw()}}
function subjectPage(id){api('/api/subjects/'+id+'?grade='+(S.user?S.user.grade:'')).then(function(d){var s=d.subject,u=d.units,keys=Object.keys(u);
 $('#view').innerHTML='<h1>'+(ICONS[s.name]||'')+' '+esc(s.name)+'</h1><p class="muted">'+esc(s.description||'')+(S.user?' · '+t('gr')+' '+S.user.grade:'')+'</p>'+
 (keys.length?'<button class="btn" data-chat="'+s.id+'">'+t('start')+'</button><h2>'+t('units')+'</h2>'+keys.map(function(k){return '<div class="card"><b>'+esc(k)+'</b><div class="srcs">'+Object.keys(u[k]).map(function(tp){return '<button class="src" data-chat="'+s.id+'" data-topic="'+esc(u[k][tp][0].topic)+'">'+esc(tp)+'</button>'}).join('')+'</div></div>'}).join('')
  :'<div class="card muted">'+t('nocont')+'</div>')})}
function startChat(sid,topic){if(!S.user){location.hash='#/account';return}api('/api/conversations',{method:'POST',body:{subject_id:+sid,topic:topic||''}}).then(function(r){location.hash='#/chat/'+r.id})}
function chatPage(id){api('/api/conversations/'+id).then(function(d){var c=d.conv;
 $('#view').innerHTML='<div class="ctx"><h1>'+esc(c.subject)+'</h1>'+(c.topic?'<span class="pill">'+esc(c.topic)+'</span>':'')+'<button class="ghost" data-new="'+c.subject_id+'">'+t('newc')+'</button></div><div class="chat" id="chat"></div>'+
  '<div class="composer"><form id="f"><button type="button" class="ghost" id="att" aria-label="'+t('ocr')+'">📎</button><input type="file" id="img" accept="image/*" hidden><textarea id="m" rows="1" placeholder="'+t('ph')+'" dir="auto"></textarea><button class="btn">'+t('send')+'</button></form></div>';
 d.messages.forEach(function(m){bubble(m)}); window.scrollTo(0,document.body.scrollHeight);
 $('#att').onclick=function(){$('#img').click()};
 $('#img').onchange=function(e){var fd=new FormData();fd.append('image',e.target.files[0]);api('/api/ocr',{method:'POST',body:fd}).then(function(r){$('#m').value=(r.text||'').trim()}).catch(function(x){alert(x.message)})};
 $('#f').onsubmit=function(e){e.preventDefault();var m=$('#m').value.trim();if(!m)return;$('#m').value='';bubble({role:'user',content:m});
  var w={role:'assistant',content:'…',sources:[]};var el=bubble(w);
  api('/api/chat',{method:'POST',body:{conversation_id:+id,message:m}}).then(function(r){el.remove();bubble({role:'assistant',content:r.text,sources:r.sources,mode:r.mode});window.scrollTo(0,document.body.scrollHeight)}).catch(function(x){el.remove();bubble({role:'assistant',content:x.message})})}})
}
function bubble(m){var d=document.createElement('div');d.className='msg '+m.role+(m.mode==='refused'?' refused':'');
 d.innerHTML=(m.role==='user'?'<span dir="auto">'+esc(m.content)+'</span>':md(m.content))+((m.sources&&m.sources.length)?'<div class="srcs"><b class="small">'+t('src')+':</b>'+m.sources.map(function(s,i){return '<button class="src" title="'+esc(s.snippet)+'">'+esc(s.title)+(s.page?' · ص'+s.page:'')+'</button>'}).join('')+'</div>':'');
 $('#chat').appendChild(d);return d}
function history(){if(!S.user){location.hash='#/account';return}api('/api/conversations').then(function(L){$('#view').innerHTML='<h1>'+t('hist')+'</h1>'+(L.length?L.map(function(c){return '<div class="card row"><a href="#/chat/'+c.id+'"><b>'+esc(c.title)+'</b><br><span class="muted small">'+esc(c.subject)+'</span></a><button class="ghost" data-del="'+c.id+'">'+t('del')+'</button></div>'}).join(''):'<p class="muted">'+t('empty')+'</p>')})}
function account(){var v=$('#view');
 if(S.user){v.innerHTML='<h1>'+esc(S.user.name)+'</h1><div class="card"><label>'+t('gr')+'<select id="g">'+[10,11,12].map(function(g){return '<option value="'+g+'"'+(S.user.grade===g?' selected':'')+'>'+t('g'+g)+'</option>'}).join('')+'</select></label><p><button class="btn" id="sv">OK</button> <button class="ghost" id="lo">'+t('out')+'</button></p></div>'+
  '<p><a href="#/about">'+t('about')+'</a> · <a href="#/info">'+t('info')+'</a></p>';
  $('#sv').onclick=function(){api('/api/me',{method:'PATCH',body:{grade:+$('#g').value}}).then(function(){S.user.grade=+$('#g').value;alert('✔')})};
  $('#lo').onclick=function(){api('/api/logout',{method:'POST'}).then(boot)};return}
 v.innerHTML='<h1>'+t('login')+'</h1><div class="card form"><label>'+t('user')+'<input id="u" autocomplete="username" dir="ltr"></label><label>'+t('pass')+'<input id="p" type="password" autocomplete="current-password"></label><button class="btn" id="li">'+t('login')+'</button><div id="er" class="flash" hidden></div></div>'+
  '<h2>'+t('reg')+'</h2><div class="card form"><label>'+t('nm')+'<input id="rn"></label><label>'+t('user')+'<input id="ru" dir="ltr"></label><label>'+t('pass')+'<input id="rp" type="password" autocomplete="new-password"></label><label>'+t('gr')+'<select id="rg"><option value="10">'+t('g10')+'</option><option value="11">'+t('g11')+'</option><option value="12">'+t('g12')+'</option></select></label><button class="btn accent" id="rg2">'+t('reg')+'</button></div>';
 function err(x){var e=$('#er');e.hidden=false;e.textContent=x.message}
 $('#li').onclick=function(){api('/api/login',{method:'POST',body:{username:$('#u').value,password:$('#p').value}}).then(function(){return boot()}).then(function(){location.hash='#/'}).catch(err)};
 $('#rg2').onclick=function(){api('/api/register',{method:'POST',body:{name:$('#rn').value,username:$('#ru').value,password:$('#rp').value,grade:+$('#rg').value}}).then(function(){return boot()}).then(function(){location.hash='#/'}).catch(err)}}
function about(info){$('#view').innerHTML='<h1>'+t(info?'info':'about')+'</h1><div class="card"><p>'+t('abt')+'</p><p>'+t('goals')+'</p><p><b>'+t('by')+'</b></p><p>'+t('date')+'</p></div>'+
 (info?'<div class="card muted small">'+(S.llm?'LLM: ON':'LLM: OFF — extractive mode')+'</div>':'')+credit()}
function route(){var h=(location.hash||'#/').slice(2).split('/');setBar();window.scrollTo(0,0);
 try{if(!h[0])home();else if(h[0]==='subject')subjectPage(h[1]);else if(h[0]==='chat')chatPage(h[1]);else if(h[0]==='history')history();else if(h[0]==='account')account();else if(h[0]==='about')about();else if(h[0]==='info')about(true);else home()}catch(e){}}
function boot(){return api('/api/me').then(function(m){S.csrf=m.csrf;S.user=m.user;S.credit={ar:m.credit_ar,en:m.credit_en};S.llm=m.llm;return api('/api/subjects')}).then(function(s){S.subjects=s.subjects;S.recent=s.recent;applyLang();route()})}
document.addEventListener('click',function(e){var b;
 if(b=e.target.closest('[data-chat]'))startChat(b.dataset.chat,b.dataset.topic);
 else if(b=e.target.closest('[data-new]'))startChat(b.dataset.new);
 else if(b=e.target.closest('[data-sid]'))location.hash='#/subject/'+b.dataset.sid;
 else if(b=e.target.closest('[data-del]')){api('/api/conversations/'+b.dataset.del,{method:'DELETE'}).then(history)}
 else if(e.target.id==='theme'){var n=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=n;localStorage.setItem('theme',n)}});
document.addEventListener('change',function(e){if(e.target.id==='lang'){S.lang=e.target.value;localStorage.setItem('lang',S.lang);applyLang();route()}});
document.documentElement.dataset.theme=localStorage.getItem('theme')||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
window.addEventListener('hashchange',route);
document.addEventListener('DOMContentLoaded',function(){$('#lang').value=S.lang;boot().catch(function(){$('#view').textContent=t('err')})});
})();
