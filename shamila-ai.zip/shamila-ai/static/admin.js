(function(){
  var t=localStorage.getItem('theme')||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
  document.documentElement.dataset.theme=t;
  document.addEventListener('click',function(e){
    var b=e.target.closest('[data-confirm]'); if(b && !confirm(b.dataset.confirm)) e.preventDefault();
    if(e.target.id==='theme'){var n=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=n;localStorage.setItem('theme',n);}
  });
})();
