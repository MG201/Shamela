import os, secrets
BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE, "data", "app.db"))
UPLOAD_DIR = os.environ.get("UPLOAD_DIR", os.path.join(BASE, "uploads"))
SECRET_FILE = os.path.join(BASE, "data", ".secret_key")
def secret_key():
    if os.environ.get("SECRET_KEY"): return os.environ["SECRET_KEY"]
    os.makedirs(os.path.dirname(SECRET_FILE), exist_ok=True)
    if not os.path.exists(SECRET_FILE):
        with open(SECRET_FILE, "w") as f: f.write(secrets.token_hex(32))
        os.chmod(SECRET_FILE, 0o600)
    return open(SECRET_FILE).read().strip()
MAX_UPLOAD_MB = int(os.environ.get("MAX_UPLOAD_MB", "40"))
ALLOWED_EXT = {"pdf", "docx", "pptx", "txt", "png", "jpg", "jpeg", "webp"}
LLM_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")      # يُخزَّن على الخادم فقط
LLM_MODEL = os.environ.get("LLM_MODEL", "claude-sonnet-5-5")
OCR_LANGS = os.environ.get("OCR_LANGS", "ara+heb+eng")
SECURE_COOKIES = os.environ.get("SECURE_COOKIES", "0") == "1"   # فعّلها خلف HTTPS
NO_ANSWER = ("عذرًا، لم تتم إضافة هذا الموضوع أو المعلومات المطلوبة إلى قاعدة المحتوى "
             "التعليمية المعتمدة بعد. يرجى مراجعة المعلم أو العودة لاحقًا.")
CREDIT_AR = ("تم التصميم والتطوير والإنشاء بواسطة الطالب: محمد عبد جبارين — الصف الحادي عشر (ز) — "
             "المدرسة الثانوية الشاملة – أم الفحم. جميع الحقوق محفوظة © 2026.")
CREDIT_EN = ("Designed & Developed by: Mohammad Abd Jabbarin — Grade 11 (Z) — "
             "Comprehensive Secondary School – Umm Al-Fahm. All Rights Reserved © 2026.")
