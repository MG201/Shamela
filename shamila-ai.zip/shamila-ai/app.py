import os, json, time, secrets, uuid, re
from functools import wraps
from flask import (Flask, request, session, jsonify, render_template, redirect, url_for, abort, send_file, flash, g)
from werkzeug.security import generate_password_hash, check_password_hash
import config, db, rag
from extract import extract
app = Flask(__name__)
app.secret_key = config.secret_key()
app.config.update(MAX_CONTENT_LENGTH=config.MAX_UPLOAD_MB * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True,
                  SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_SECURE=config.SECURE_COOKIES)
os.makedirs(config.UPLOAD_DIR, exist_ok=True); db.init()
STATUS_AR = {"draft": "مسودة", "review": "قيد المراجعة", "approved": "معتمد", "published": "منشور", "hidden": "مخفي", "revoked": "ملغى الاعتماد"}
FLOW = {"draft": ["review"], "review": ["approved", "draft"], "approved": ["published", "review"],
        "published": ["hidden", "revoked"], "hidden": ["published", "revoked"], "revoked": ["review"]}
ACTION_TO = {"review": "review", "approve": "approved", "publish": "published", "hide": "hidden", "revoke": "revoked", "draft": "draft"}
app.jinja_env.globals.update(STATUS_AR=STATUS_AR, CREDIT_AR=config.CREDIT_AR, CREDIT_EN=config.CREDIT_EN, FLOW=FLOW)

# ---------- أمان ----------
@app.after_request
def headers(r):
    r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "same-origin",
        "Content-Security-Policy": "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'"})
    if request.path.startswith(("/api", "/admin")): r.headers["Cache-Control"] = "no-store"
    return r
def csrf_token():
    if "csrf" not in session: session["csrf"] = secrets.token_urlsafe(24)
    return session["csrf"]
app.jinja_env.globals["csrf"] = csrf_token
@app.before_request
def csrf_check():
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and request.endpoint != "static":
        tok = request.headers.get("X-CSRF") or request.form.get("csrf")
        if not tok or tok != session.get("csrf"): abort(403)
_fails = {}
def throttle(key, limit=8, window=300):
    now = time.time(); L = [t for t in _fails.get(key, []) if now - t < window]; _fails[key] = L
    return len(L) >= limit
def fail(key): _fails.setdefault(key, []).append(time.time())
def cur_user():
    if "uid" not in session: return None
    c = db.conn(); u = c.execute("SELECT * FROM users WHERE id=?", (session["uid"],)).fetchone(); c.close(); return u
def need_student(f):
    @wraps(f)
    def w(*a, **k):
        u = cur_user()
        if not u: return jsonify(error="login"), 401
        g.user = u; return f(*a, **k)
    return w
def need_admin(f):
    @wraps(f)
    def w(*a, **k):
        u = cur_user()
        if not u or u["role"] != "admin": return redirect(url_for("admin_login"))
        g.user = u; return f(*a, **k)
    return w
def bootstrap_admin():
    c = db.conn()
    if not c.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
        u, p = os.environ.get("ADMIN_USER"), os.environ.get("ADMIN_PASS")
        if u and p and len(p) >= 10:
            c.execute("INSERT INTO users(name,username,pw,role,created) VALUES(?,?,?,?,?)", ("المدير", u, generate_password_hash(p), "admin", time.time())); c.commit()
    c.close()
bootstrap_admin()

# ---------- واجهة الطالب ----------
@app.route("/")
def root(): return redirect("/app")
@app.route("/app")
def student_app(): return render_template("app.html")
@app.get("/api/me")
def api_me():
    u = cur_user(); tok = csrf_token()
    return jsonify(csrf=tok, user=None if not u or u["role"] != "student" else {"name": u["name"], "username": u["username"], "grade": u["grade"]},
                   credit_ar=config.CREDIT_AR, credit_en=config.CREDIT_EN, llm=bool(config.LLM_API_KEY))
@app.post("/api/register")
def api_register():
    d = request.get_json(force=True, silent=True) or {}
    name, un, pw, gr = (d.get("name") or "").strip(), (d.get("username") or "").strip().lower(), d.get("password") or "", d.get("grade")
    if not (2 <= len(name) <= 60 and re.fullmatch(r"[a-z0-9_.]{3,30}", un) and len(pw) >= 8 and gr in (10, 11, 12)):
        return jsonify(error="بيانات غير صالحة: اسم المستخدم 3-30 حرفًا لاتينيًا/أرقام، وكلمة المرور 8 أحرف على الأقل، والصف 10-12"), 400
    c = db.conn()
    try: cur = c.execute("INSERT INTO users(name,username,pw,role,grade,created) VALUES(?,?,?,?,?,?)", (name, un, generate_password_hash(pw), "student", gr, time.time())); c.commit()
    except Exception: c.close(); return jsonify(error="اسم المستخدم مستخدم مسبقًا"), 409
    session.clear(); session["uid"] = cur.lastrowid; c.close(); db.log(un, "register"); return jsonify(ok=True, csrf=csrf_token())
@app.post("/api/login")
def api_login():
    d = request.get_json(force=True, silent=True) or {}; un = (d.get("username") or "").strip().lower(); key = "s:" + un + request.remote_addr
    if throttle(key): return jsonify(error="محاولات كثيرة، حاول بعد قليل"), 429
    c = db.conn(); u = c.execute("SELECT * FROM users WHERE username=? AND role='student'", (un,)).fetchone(); c.close()
    if not u or not check_password_hash(u["pw"], d.get("password") or ""): fail(key); return jsonify(error="بيانات الدخول غير صحيحة"), 401
    session.clear(); session["uid"] = u["id"]; db.log(un, "login"); return jsonify(ok=True, csrf=csrf_token())
@app.post("/api/logout")
def api_logout(): session.clear(); return jsonify(ok=True)
@app.patch("/api/me")
@need_student
def api_me_patch():
    d = request.get_json(force=True, silent=True) or {}; c = db.conn()
    if d.get("grade") in (10, 11, 12): c.execute("UPDATE users SET grade=? WHERE id=?", (d["grade"], g.user["id"]))
    if (d.get("name") or "").strip(): c.execute("UPDATE users SET name=? WHERE id=?", (d["name"].strip()[:60], g.user["id"]))
    if d.get("password"):
        if len(d["password"]) < 8 or not check_password_hash(g.user["pw"], d.get("old") or ""): c.close(); return jsonify(error="كلمة المرور الحالية خاطئة أو الجديدة قصيرة"), 400
        c.execute("UPDATE users SET pw=? WHERE id=?", (generate_password_hash(d["password"]), g.user["id"]))
    c.commit(); c.close(); return jsonify(ok=True)
@app.get("/api/subjects")
def api_subjects():
    c = db.conn(); rows = c.execute("""SELECT s.*, (SELECT COUNT(DISTINCT CASE WHEN i.topic<>'' THEN i.topic ELSE 'item'||i.id END) FROM items i
        WHERE i.subject_id=s.id AND i.status='published') topics FROM subjects s ORDER BY kind, pos, id""").fetchall()
    recent = c.execute("SELECT i.title,s.name subject,s.id sid,i.created FROM items i JOIN subjects s ON s.id=i.subject_id WHERE i.status='published' ORDER BY i.updated DESC LIMIT 5").fetchall(); c.close()
    return jsonify(subjects=[{**dict(r), "available": r["topics"] > 0} for r in rows], recent=[dict(r) for r in recent])
@app.get("/api/subjects/<int:sid>")
def api_subject(sid):
    grade = request.args.get("grade", type=int); c = db.conn(); s = c.execute("SELECT * FROM subjects WHERE id=?", (sid,)).fetchone()
    if not s: c.close(); abort(404)
    q = "SELECT id,title,kind,grade,semester,unit,topic,source,teacher FROM items WHERE subject_id=? AND status='published'"; a = [sid]
    if grade: q += " AND (grade=0 OR grade=?)"; a.append(grade)
    items = [dict(r) for r in c.execute(q + " ORDER BY unit,topic,id", a)]; c.close()
    units = {}
    for it in items: units.setdefault(it["unit"] or "عام", {}).setdefault(it["topic"] or it["title"], []).append(it)
    return jsonify(subject=dict(s), units=units, items=items)
def own_conv(cid):
    c = db.conn(); r = c.execute("SELECT * FROM convs WHERE id=? AND user_id=?", (cid, g.user["id"])).fetchone(); c.close()
    if not r: abort(404)
    return r
@app.get("/api/conversations")
@need_student
def api_convs():
    c = db.conn(); rows = c.execute("SELECT c.id,c.title,c.topic,c.created,s.name subject,c.subject_id FROM convs c JOIN subjects s ON s.id=c.subject_id WHERE c.user_id=? ORDER BY c.id DESC LIMIT 200", (g.user["id"],)).fetchall(); c.close()
    return jsonify([dict(r) for r in rows])
@app.post("/api/conversations")
@need_student
def api_conv_new():
    d = request.get_json(force=True, silent=True) or {}; c = db.conn()
    if not c.execute("SELECT 1 FROM subjects WHERE id=?", (d.get("subject_id"),)).fetchone(): c.close(); abort(404)
    cur = c.execute("INSERT INTO convs(user_id,subject_id,topic,title,created) VALUES(?,?,?,?,?)", (g.user["id"], d["subject_id"], (d.get("topic") or "")[:200], "محادثة جديدة", time.time())); c.commit(); i = cur.lastrowid; c.close()
    return jsonify(id=i)
@app.get("/api/conversations/<int:cid>")
@need_student
def api_conv(cid):
    cv = own_conv(cid); c = db.conn(); ms = c.execute("SELECT role,content,sources,mode FROM msgs WHERE conv_id=? ORDER BY id", (cid,)).fetchall()
    s = c.execute("SELECT name FROM subjects WHERE id=?", (cv["subject_id"],)).fetchone(); c.close()
    return jsonify(conv={**dict(cv), "subject": s["name"]}, messages=[{**dict(m), "sources": json.loads(m["sources"])} for m in ms])
@app.delete("/api/conversations/<int:cid>")
@need_student
def api_conv_del(cid):
    own_conv(cid); c = db.conn(); c.execute("DELETE FROM convs WHERE id=?", (cid,)); c.commit(); c.close(); return jsonify(ok=True)
@app.post("/api/chat")
@need_student
def api_chat():
    d = request.get_json(force=True, silent=True) or {}; q = (d.get("message") or "").strip()[:2000]
    if not q: return jsonify(error="اكتب سؤالًا"), 400
    cv = own_conv(d.get("conversation_id")); c = db.conn()
    hist = [dict(m) for m in c.execute("SELECT role,content FROM msgs WHERE conv_id=? ORDER BY id DESC LIMIT 6", (cv["id"],))][::-1]
    res = rag.answer(cv["subject_id"], q, g.user["grade"], cv["topic"], hist)
    c.execute("INSERT INTO msgs(conv_id,role,content,created) VALUES(?,?,?,?)", (cv["id"], "user", q, time.time()))
    c.execute("INSERT INTO msgs(conv_id,role,content,sources,mode,created) VALUES(?,?,?,?,?,?)", (cv["id"], "assistant", res["text"], json.dumps(res["sources"], ensure_ascii=False), res["mode"], time.time()))
    if cv["title"] == "محادثة جديدة": c.execute("UPDATE convs SET title=? WHERE id=?", (q[:50], cv["id"]))
    c.commit(); c.close(); db.log(g.user["username"], "ask", res["mode"]); return jsonify(res)
@app.post("/api/ocr")
@need_student
def api_ocr():
    f = request.files.get("image"); ext = (f.filename.rsplit(".", 1)[-1].lower() if f and "." in f.filename else "")
    if ext not in ("png", "jpg", "jpeg", "webp"): return jsonify(error="صورة غير مدعومة"), 400
    p = os.path.join(config.UPLOAD_DIR, "tmp_" + uuid.uuid4().hex + "." + ext); f.save(p)
    try: txt = extract(p, ext)[0][1]
    except Exception as e: txt = ""
    finally: os.remove(p)
    return jsonify(text=txt[:1500])

# ---------- لوحة الإدارة ----------
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        un = request.form.get("username", "").strip().lower(); key = "a:" + request.remote_addr
        if throttle(key, 5): flash("محاولات كثيرة، حاول لاحقًا"); return render_template("admin_login.html")
        c = db.conn(); u = c.execute("SELECT * FROM users WHERE username=? AND role='admin'", (un,)).fetchone(); c.close()
        if u and check_password_hash(u["pw"], request.form.get("password", "")):
            session.clear(); session["uid"] = u["id"]; db.log(un, "admin_login"); return redirect(url_for("admin_home"))
        fail(key); db.log(un or "?", "admin_login_failed"); flash("بيانات الدخول غير صحيحة")
    return render_template("admin_login.html")
@app.post("/admin/logout")
def admin_logout(): session.clear(); return redirect(url_for("admin_login"))
@app.route("/admin")
@need_admin
def admin_home():
    c = db.conn(); one = lambda q, *a: c.execute(q, a).fetchone()[0]
    st = {k: one("SELECT COUNT(*) FROM items WHERE status=?", k) for k in STATUS_AR}
    data = dict(subjects=one("SELECT COUNT(*) FROM subjects WHERE kind='core'"), tracks=one("SELECT COUNT(*) FROM subjects WHERE kind='track'"),
        topics=one("SELECT COUNT(DISTINCT topic) FROM items WHERE topic<>''"), files=one("SELECT COUNT(*) FROM items"), st=st,
        students=one("SELECT COUNT(*) FROM users WHERE role='student'"), convs=one("SELECT COUNT(*) FROM convs"),
        top=c.execute("SELECT s.name,COUNT(*) n FROM convs c JOIN subjects s ON s.id=c.subject_id GROUP BY s.id ORDER BY n DESC LIMIT 5").fetchall(),
        act=c.execute("SELECT * FROM activity ORDER BY id DESC LIMIT 12").fetchall()); c.close()
    return render_template("admin_home.html", **data, fmt=fmt)
def fmt(ts): return time.strftime("%Y-%m-%d %H:%M", time.localtime(ts)) if ts else "—"
@app.route("/admin/subjects", methods=["GET", "POST"])
@need_admin
def admin_subjects():
    c = db.conn()
    if request.method == "POST":
        a = request.form.get("do"); sid = request.form.get("id")
        if a == "add" and request.form.get("name", "").strip():
            c.execute("INSERT INTO subjects(name,kind,description,pos) VALUES(?,?,?,?)", (request.form["name"].strip(), request.form.get("kind", "core"), request.form.get("description", ""), 500))
        elif a == "edit": c.execute("UPDATE subjects SET name=?,kind=?,description=? WHERE id=?", (request.form["name"].strip(), request.form.get("kind", "core"), request.form.get("description", ""), sid))
        elif a == "delete": c.execute("DELETE FROM subjects WHERE id=?", (sid,))
        c.commit(); db.log(g.user["username"], "subject_" + str(a), request.form.get("name", sid)); return redirect(url_for("admin_subjects"))
    rows = c.execute("SELECT s.*,(SELECT COUNT(*) FROM items WHERE subject_id=s.id) n FROM subjects s ORDER BY kind,pos,id").fetchall(); c.close()
    return render_template("admin_subjects.html", rows=rows)
def save_pages(c, iid, pages):
    c.execute("DELETE FROM pages WHERE item_id=?", (iid,))
    for p, t in pages: c.execute("INSERT INTO pages(item_id,page,text) VALUES(?,?,?)", (iid, p, t))
def meta_from_form(f):
    return dict(subject_id=int(f["subject_id"]), title=f.get("title", "").strip() or "بدون عنوان", grade=int(f.get("grade") or 0), semester=f.get("semester", ""),
        unit=f.get("unit", "").strip(), topic=f.get("topic", "").strip(), source=f.get("source", "").strip(), teacher=f.get("teacher", "").strip(), page_note=f.get("page_note", "").strip())
@app.route("/admin/content")
@need_admin
def admin_content():
    c = db.conn(); sid, stt = request.args.get("subject", type=int), request.args.get("status")
    q = "SELECT i.*,s.name subject,(SELECT COUNT(*) FROM chunks WHERE item_id=i.id) nchunks FROM items i JOIN subjects s ON s.id=i.subject_id WHERE 1=1"; a = []
    if sid: q += " AND i.subject_id=?"; a.append(sid)
    if stt: q += " AND i.status=?"; a.append(stt)
    rows = c.execute(q + " ORDER BY i.id DESC", a).fetchall(); subs = c.execute("SELECT id,name FROM subjects ORDER BY kind,pos").fetchall(); c.close()
    return render_template("admin_content.html", rows=rows, subs=subs, sid=sid, stt=stt, fmt=fmt)
@app.route("/admin/content/new", methods=["GET", "POST"])
@need_admin
def admin_new():
    c = db.conn(); subs = c.execute("SELECT id,name FROM subjects ORDER BY kind,pos").fetchall()
    if request.method == "POST":
        m = meta_from_form(request.form); f = request.files.get("file"); body = request.form.get("body", "").strip(); now = time.time()
        if f and f.filename:
            ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
            if ext not in config.ALLOWED_EXT: c.close(); flash("نوع الملف غير مسموح"); return redirect(url_for("admin_new"))
            stored = uuid.uuid4().hex + "." + ext; path = os.path.join(config.UPLOAD_DIR, stored); f.save(path)
            if m["title"] == "بدون عنوان": m["title"] = f.filename
            cur = c.execute("INSERT INTO items(subject_id,kind,title,grade,semester,unit,topic,source,teacher,page_note,status,filename,stored,ext,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (m["subject_id"], "file", m["title"], m["grade"], m["semester"], m["unit"], m["topic"], m["source"], m["teacher"], m["page_note"], "draft", f.filename, stored, ext, now, now))
            iid = cur.lastrowid
            try: save_pages(c, iid, extract(path, ext)); c.execute("UPDATE items SET extract_state='done' WHERE id=?", (iid,)); rag.reindex(c, iid)
            except Exception as e: c.execute("UPDATE items SET extract_state='failed',error=? WHERE id=?", (str(e)[:300], iid))
        elif body:
            cur = c.execute("INSERT INTO items(subject_id,kind,title,grade,semester,unit,topic,source,teacher,page_note,status,extract_state,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (m["subject_id"], "lesson", m["title"], m["grade"], m["semester"], m["unit"], m["topic"], m["source"], m["teacher"], m["page_note"], "draft", "done", now, now))
            iid = cur.lastrowid; save_pages(c, iid, [(1, body)]); rag.reindex(c, iid)
        else: c.close(); flash("ارفع ملفًا أو اكتب نصًا"); return redirect(url_for("admin_new"))
        c.commit(); c.close(); db.log(g.user["username"], "content_create", m["title"]); return redirect(url_for("admin_item", iid=iid))
    c.close(); return render_template("admin_new.html", subs=subs)
@app.route("/admin/content/<int:iid>", methods=["GET", "POST"])
@need_admin
def admin_item(iid):
    c = db.conn(); it = c.execute("SELECT i.*,s.name subject FROM items i JOIN subjects s ON s.id=i.subject_id WHERE i.id=?", (iid,)).fetchone()
    if not it: c.close(); abort(404)
    if request.method == "POST":
        a = request.form.get("do"); u = g.user["username"]
        if a == "meta":
            m = meta_from_form(request.form); c.execute("UPDATE items SET subject_id=?,title=?,grade=?,semester=?,unit=?,topic=?,source=?,teacher=?,page_note=?,updated=? WHERE id=?",
                (*m.values(), time.time(), iid))
            if it["status"] in ("published", "approved"): c.execute("UPDATE items SET status='review' WHERE id=?", (iid,)); flash("تغيّرت البيانات الوصفية؛ أُعيد إلى المراجعة وأُوقف استخدامه حتى تعتمده")
            db.log(u, "content_edit", it["title"], c=c)
        elif a == "text":   # تحرير النص المستخرج: يوقف الاستخدام فورًا
            parts = re.split(r"^=== صفحة (\d+) ===\s*$", request.form.get("text", ""), flags=re.M); pages = []
            if len(parts) > 1: pages = [(int(parts[i]), parts[i + 1].strip()) for i in range(1, len(parts), 2)]
            else: pages = [(1, request.form.get("text", "").strip())]
            save_pages(c, iid, pages); c.execute("UPDATE items SET extract_state='done',error='',status='review',updated=? WHERE id=?", (time.time(), iid)); rag.reindex(c, iid)
            flash("حُفظ النص وأُعيد الملف إلى «قيد المراجعة»"); db.log(u, "content_text_edit", it["title"], c=c)
        elif a == "reindex":
            if it["kind"] == "file" and it["stored"]:
                try: save_pages(c, iid, extract(os.path.join(config.UPLOAD_DIR, it["stored"]), it["ext"])); c.execute("UPDATE items SET extract_state='done',error='' WHERE id=?", (iid,))
                except Exception as e: c.execute("UPDATE items SET extract_state='failed',error=? WHERE id=?", (str(e)[:300], iid))
            rag.reindex(c, iid); db.log(u, "reindex", it["title"], c=c)
        elif a in ACTION_TO:
            to = ACTION_TO[a]; n = c.execute("SELECT COUNT(*) FROM chunks WHERE item_id=?", (iid,)).fetchone()[0]
            if to not in FLOW[it["status"]]: flash("انتقال غير مسموح من هذه الحالة")
            elif to in ("approved", "published") and n == 0: flash("لا يوجد نص مفهرس؛ لا يمكن الاعتماد")
            else: c.execute("UPDATE items SET status=?,updated=? WHERE id=?", (to, time.time(), iid)); db.log(u, "status_" + to, it["title"], c=c); flash("تم: " + STATUS_AR[to])
        elif a == "delete":
            if it["stored"]:
                try: os.remove(os.path.join(config.UPLOAD_DIR, it["stored"]))
                except OSError: pass
            c.execute("DELETE FROM items WHERE id=?", (iid,)); c.commit(); c.close(); db.log(u, "content_delete", it["title"]); return redirect(url_for("admin_content"))
        c.commit(); c.close(); return redirect(url_for("admin_item", iid=iid))
    pages = c.execute("SELECT page,text FROM pages WHERE item_id=? ORDER BY page", (iid,)).fetchall()
    n = c.execute("SELECT COUNT(*) FROM chunks WHERE item_id=?", (iid,)).fetchone()[0]; subs = c.execute("SELECT id,name FROM subjects ORDER BY kind,pos").fetchall(); c.close()
    text = "\n\n".join(f"=== صفحة {p['page']} ===\n{p['text']}" for p in pages)
    return render_template("admin_item.html", it=it, text=text, n=n, subs=subs, fmt=fmt)
@app.get("/admin/files/<int:iid>")
@need_admin
def admin_file(iid):
    c = db.conn(); it = c.execute("SELECT * FROM items WHERE id=?", (iid,)).fetchone(); c.close()
    if not it or not it["stored"]: abort(404)
    return send_file(os.path.join(config.UPLOAD_DIR, it["stored"]), download_name=it["filename"], as_attachment=True)
@app.route("/admin/kb")
@need_admin
def admin_kb():
    c = db.conn(); rows = c.execute("SELECT i.*,s.name subject,(SELECT COUNT(*) FROM chunks WHERE item_id=i.id) nchunks FROM items i JOIN subjects s ON s.id=i.subject_id ORDER BY i.updated DESC").fetchall()
    tot = c.execute("SELECT COUNT(*) FROM chunks ch JOIN items i ON i.id=ch.item_id WHERE i.status='published'").fetchone()[0]; c.close()
    return render_template("admin_kb.html", rows=rows, tot=tot, fmt=fmt)
@app.route("/admin/students")
@need_admin
def admin_students():
    c = db.conn(); rows = c.execute("SELECT u.*,(SELECT COUNT(*) FROM convs WHERE user_id=u.id) n FROM users u WHERE role='student' ORDER BY id DESC").fetchall()
    act = c.execute("SELECT * FROM activity ORDER BY id DESC LIMIT 100").fetchall(); c.close()
    return render_template("admin_students.html", rows=rows, act=act, fmt=fmt)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
