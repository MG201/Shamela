"""اختبارات شاملة: python tests/test_all.py   (تستخدم قاعدة بيانات مؤقتة؛ الفقرات النموذجية هنا بيانات اختبار فقط ولا تُشحن مع التطبيق)"""
import os, sys, tempfile, subprocess, re, io, collections
tmp = tempfile.mkdtemp(); os.environ.update(DB_PATH=tmp + "/t.db", UPLOAD_DIR=tmp, ADMIN_USER="admin", ADMIN_PASS="Adm1n-Pass-2026")
os.environ.pop("ANTHROPIC_API_KEY", None)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as A, config
R = []
def check(n, ok, extra=""): ok = bool(ok); R.append(ok); print(("PASS" if ok else "FAIL"), n, extra)
def client():
    c = A.app.test_client(); c.csrf = ""; return c
def gettok(c): c.csrf = c.get("/api/me").json["csrf"]; return c.csrf
def post(c, url, **kw): return c.post(url, headers={"X-CSRF": c.csrf}, **kw)
def form(c, url, data, **kw):
    d = dict(data, csrf=c.csrf)
    return c.post(url, data=d, **kw)
def admin():
    c = client(); gettok(c); c.get("/admin/login")
    r = form(c, "/admin/login", {"username": "admin", "password": "Adm1n-Pass-2026"}); assert r.status_code == 302, r.status_code; return c
# --- ملف PDF عربي حقيقي (Word → PDF عبر LibreOffice) ---
import docx
d = docx.Document(); p = d.add_paragraph("تفاعل البوليميراز المتسلسل PCR هو تقنية لتضخيم مقطع من الحمض النووي. تمر العملية بثلاث مراحل: المسخ ثم التهجين ثم الاستطالة.")
p.alignment = 2; d.add_page_break(); d.add_paragraph("الطفرات هي تغيّرات في تسلسل القواعد النيتروجينية في الحمض النووي.").alignment = 2
d.save(tmp + "/pcr.docx"); subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", tmp, tmp + "/pcr.docx"], capture_output=True, timeout=120)
adm = admin(); biot = [s for s in __import__("db").conn().execute("SELECT * FROM subjects")]
sid = [s["id"] for s in biot if s["name"] == "البيوتكنولوجيا"][0]; sid2 = [s["id"] for s in biot if s["name"] == "الكيمياء"][0]
def upload(path, **m):
    data = dict(subject_id=sid, grade="11", unit="الوحدة 1", topic="PCR", title="ملف اختبار", source="اختبار", csrf=adm.csrf or "", **m)
    adm.csrf = gettok(adm); data["csrf"] = adm.csrf
    data["file"] = (open(path, "rb"), os.path.basename(path)); r = adm.post("/admin/content/new", data=data, content_type="multipart/form-data")
    return int(r.headers["Location"].rsplit("/", 1)[1])
st = lambda i: A.db.conn().execute("SELECT status FROM items WHERE id=?", (i,)).fetchone()
def act(i, a): return form(adm, f"/admin/content/{i}", {"do": a})
# بنية فارغة
c0 = A.db.conn(); check("0. المواد هياكل فارغة (18 مادة، 0 ملفات، 0 مقاطع)", c0.execute("SELECT COUNT(*) FROM subjects").fetchone()[0] == 18 and c0.execute("SELECT COUNT(*) FROM items").fetchone()[0] == 0)
# 1-3
pdf = upload(tmp + "/pcr.pdf"); c = A.db.conn()
pg = c.execute("SELECT page,text FROM pages WHERE item_id=?", (pdf,)).fetchall()
check("1-2. رفع PDF واستخراج النص من صفحتين", len(pg) == 2 and "PCR" in pg[0]["text"], f"({len(pg)} صفحات)")
check("3. المعاينة تعرض النص", "PCR" in adm.get(f"/admin/content/{pdf}").get_data(as_text=True))
# 10-11 غير معتمد
s = client(); gettok(s); s.csrf = post(s, "/api/register", json={"name": "طالب", "username": "stu1", "password": "password123", "grade": 11}).json["csrf"]
cid = post(s, "/api/conversations", json={"subject_id": sid}).json["id"]
ask = lambda q, cid=cid, cl=s: post(cl, "/api/chat", json={"conversation_id": cid, "message": q}).json
r = ask("اشرح لي عملية PCR"); check("10-11. ملف غير معتمد (مسودة) لا يُستخدم", r["mode"] == "refused" and r["text"] == config.NO_ANSWER)
for a in ("review", "approve"): act(pdf, a)
r = ask("اشرح لي عملية PCR"); check("   ملف 'معتمد' غير منشور لا يُستخدم أيضًا", r["mode"] == "refused")
# 4-7 اعتماد ونشر
act(pdf, "publish"); check("4. الاعتماد والنشر", st(pdf)["status"] == "published")
r = ask("اشرح لي عملية PCR")
check("5-6. إجابة مستندة للمصدر", r["mode"] in ("extractive", "llm") and "التهجين" in r["text"] and r["sources"], r["mode"])
check("7. رقم الصفحة يظهر", r["sources"][0]["page"] == 1 and "ص1" in r["text"])
r2 = ask("ما هي الطفرات"); check("   الصفحة 2 تُسترجع برقمها", r2["sources"] and r2["sources"][0]["page"] == 2)
# 8-9 موضوع غير موجود + عزل المواد
for q in ("اشرح لي الثورة الفرنسية", "ما هي عاصمة فرنسا"):
    check("8-9. رفض موضوع غير موجود: " + q, ask(q)["text"] == config.NO_ANSWER)
cid2 = post(s, "/api/conversations", json={"subject_id": sid2}).json["id"]
check("   لا خلط بين المواد (سؤال عن PCR في الكيمياء)", ask("اشرح لي عملية PCR", cid2)["text"] == config.NO_ANSWER)
r = ask("اشرح لي عملية PCR وعملية الاستنساخ"); check("   جواب جزئي يحدد غير المتوفر", "لا تتوفر" in r["text"] and "استنساخ" in r["text"])
# 12-13 إلغاء الاعتماد
act(pdf, "revoke"); check("12-13. إلغاء الاعتماد يوقف الاستخدام فورًا", ask("اشرح لي عملية PCR")["mode"] == "refused" and st(pdf)["status"] == "revoked")
# تحرير النص يوقف الاستخدام
act(pdf, "review"); act(pdf, "approve"); act(pdf, "publish"); assert ask("المسخ")["mode"] != "refused"
form(adm, f"/admin/content/{pdf}", {"do": "text", "text": "=== صفحة 1 ===\nنص جديد فقط عن الضوء."}); check("   تحرير النص يعيده للمراجعة ويوقفه", st(pdf)["status"] == "review" and ask("المسخ")["mode"] == "refused")
# 14 حذف
act(pdf, "review"); act(pdf, "approve"); act(pdf, "publish"); act(pdf, "delete")
cc = A.db.conn(); check("14. حذف الملف يحذف مقاطعه ويوقف استخدامه", cc.execute("SELECT COUNT(*) FROM chunks").fetchone()[0] == 0 and ask("نص جديد الضوء")["mode"] == "refused" and not os.path.exists(os.path.join(tmp, "x")))
# 16 عبرية/عربية/إنجليزية عبر TXT
for name, txt, q in (("he", "פוטוסינתזה היא תהליך שבו צמחים הופכים אור שמש לאנרגיה כימית.", "הסבר לי פוטוסינתזה"),
                     ("en", "Photosynthesis converts light energy into chemical energy in chloroplasts.", "explain photosynthesis"),
                     ("ar", "التمثيل الضوئي عملية تحول فيها النباتات الطاقة الضوئية إلى طاقة كيميائية.", "اشرح التمثيل الضوئي")):
    open(f"{tmp}/{name}.txt", "w", encoding="utf8").write(txt); i = upload(f"{tmp}/{name}.txt"); [act(i, a) for a in ("review", "approve", "publish")]
    r = ask(q); check(f"16. استرجاع بلغة {name}", r["mode"] != "refused" and r["sources"])
# درس مكتوب (محرر)
adm.csrf = gettok(adm); rr = adm.post("/admin/content/new", data=dict(csrf=adm.csrf, subject_id=sid, grade="0", title="درس مكتوب", topic="جدول", unit="u", body="المرحلة | الوصف\nالمسخ | فصل الشريطين"))
li = int(rr.headers["Location"].rsplit("/", 1)[1]); [act(li, a) for a in ("review", "approve", "publish")]
check("   درس مكتوب يدويًا يُفهرس ويُجاب منه", "فصل" in ask("ما هو المسخ")["text"])
# 15 صلاحيات
anon = client(); gettok(anon)
check("15. الزائر لا يدخل /admin", anon.get("/admin").status_code == 302)
check("   الطالب لا يدخل /admin", s.get("/admin").status_code == 302 and s.get("/admin/content").status_code == 302)
check("   دخول الإدارة بحساب طالب مرفوض", form(client_ := (lambda c: (gettok(c), c)[1])(client()), "/admin/login", {"username": "stu1", "password": "password123"}).status_code == 200)
check("   تنزيل الملفات محمي", s.get("/admin/files/1").status_code == 302)
check("   POST بلا CSRF مرفوض", s.post("/api/chat", json={"conversation_id": cid, "message": "x"}).status_code == 403)
s2 = client(); gettok(s2); s2.csrf = post(s2, "/api/register", json={"name": "ثانٍ", "username": "stu2", "password": "password123", "grade": 10}).json["csrf"]
check("   طالب لا يرى محادثات غيره", s2.get(f"/api/conversations/{cid}").status_code == 404 and post(s2, "/api/chat", json={"conversation_id": cid, "message": "x"}).status_code == 404 and s2.get("/api/conversations").json == [])
check("   الطالب لا يستطيع تعديل المحتوى", post(s, "/admin/content/new").status_code in (302, 403))
check("   رفع امتداد غير مسموح", (lambda: (open(tmp + "/x.exe", "wb").write(b"x"), "/admin/content/new") and adm.post("/admin/content/new", data=dict(csrf=gettok(adm), subject_id=sid, file=(open(tmp + "/x.exe", "rb"), "x.exe")), content_type="multipart/form-data").status_code == 302)())
check("   حقن HTML في عنوان لا يُنفَّذ", "<script>alert(1)" not in adm.get("/admin/content").get_data(as_text=True))
# 20 حقوق الملكية
H = lambda r: r.get_data(as_text=True)
js = open(os.path.join(config.BASE, "static/app.js"), encoding="utf8").read()
spots = {"الصفحة الرئيسية": "function home" in js and "credit()" in js.split("function home")[1].split("function subjectPage")[0], "أسفل التطبيق": "محمد عبد جبارين" in H(client().get("/app")),
        "عن المشروع": "credit()" in js.split("function about")[1].split("function route")[0] and "محمد عبد جبارين" in js, "لوحة الإدارة": "محمد عبد جبارين" in H(adm.get("/admin")),
        "دخول الإدارة": "Mohammad Abd Jabbarin" in H(client().get("/admin/login")), "معلومات التطبيق": "about(true)" in js}
for k, v in spots.items(): check("20. حقوق الملكية: " + k, v)
# 19 الألوان
from PIL import Image
im = Image.open(os.path.join(config.BASE, "static/logo.png")).convert("RGBA"); cnt = collections.Counter(p[:3] for p in im.getdata() if p[3] > 200)
top = ["#%02X%02X%02X" % c for c, _ in cnt.most_common(2)]; tok = open(os.path.join(config.BASE, "static/tokens.css")).read()
check("19. ألوان tokens.css = ألوان الشعار المقاسة", all(t in tok for t in top), str(top))
print(f"\n{sum(R)}/{len(R)} passed"); sys.exit(0 if all(R) else 1)
