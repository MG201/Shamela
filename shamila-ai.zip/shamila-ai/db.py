import sqlite3, os, time
from config import DB_PATH
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, username TEXT UNIQUE, pw TEXT,
  role TEXT DEFAULT 'student', grade INTEGER, created REAL);
CREATE TABLE IF NOT EXISTS subjects(id INTEGER PRIMARY KEY, name TEXT, kind TEXT DEFAULT 'core',
  icon TEXT DEFAULT 'book', description TEXT DEFAULT '', pos INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY, subject_id INTEGER REFERENCES subjects(id) ON DELETE CASCADE,
  kind TEXT DEFAULT 'file', title TEXT, grade INTEGER DEFAULT 0, semester TEXT DEFAULT '', unit TEXT DEFAULT '',
  topic TEXT DEFAULT '', source TEXT DEFAULT '', teacher TEXT DEFAULT '', page_note TEXT DEFAULT '',
  status TEXT DEFAULT 'draft', filename TEXT, stored TEXT, ext TEXT, extract_state TEXT DEFAULT 'pending',
  error TEXT DEFAULT '', created REAL, updated REAL, indexed REAL);
CREATE TABLE IF NOT EXISTS pages(id INTEGER PRIMARY KEY, item_id INTEGER REFERENCES items(id) ON DELETE CASCADE,
  page INTEGER, text TEXT);
CREATE TABLE IF NOT EXISTS chunks(id INTEGER PRIMARY KEY, item_id INTEGER REFERENCES items(id) ON DELETE CASCADE,
  page INTEGER, idx INTEGER, text TEXT, terms TEXT);
CREATE INDEX IF NOT EXISTS ix_chunks_item ON chunks(item_id);
CREATE TABLE IF NOT EXISTS convs(id INTEGER PRIMARY KEY, user_id INTEGER, subject_id INTEGER, topic TEXT DEFAULT '',
  title TEXT, created REAL);
CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY, conv_id INTEGER REFERENCES convs(id) ON DELETE CASCADE,
  role TEXT, content TEXT, sources TEXT DEFAULT '[]', mode TEXT DEFAULT '', created REAL);
CREATE TABLE IF NOT EXISTS activity(id INTEGER PRIMARY KEY, who TEXT, action TEXT, detail TEXT, created REAL);
"""
CORE = ["اللغة العربية","اللغة العبرية","اللغة الإنجليزية","الرياضيات","التاريخ","المدنيات",
        "التربية الإسلامية","التربية البدنية والرياضة","التربية الاجتماعية","التربية الوطنية"]
TRACKS = ["البيولوجيا","البيوتكنولوجيا","الكيمياء","علوم البيئة","علم الحاسوب وهندسة البرامج",
          "علم المعلومات والبيانات","الهندسة المعمارية","الميكاترونيكا والروبوتيكا"]
def conn():
    c = sqlite3.connect(DB_PATH, timeout=30); c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON"); c.execute("PRAGMA journal_mode=WAL"); return c
def init():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    c = conn(); c.executescript(SCHEMA)
    if not c.execute("SELECT 1 FROM subjects").fetchone():   # هياكل فارغة فقط — بلا أي محتوى تعليمي
        for i, n in enumerate(CORE): c.execute("INSERT INTO subjects(name,kind,pos) VALUES(?,?,?)", (n,"core",i))
        for i, n in enumerate(TRACKS): c.execute("INSERT INTO subjects(name,kind,pos) VALUES(?,?,?)", (n,"track",100+i))
    c.commit(); c.close()
def log(who, action, detail="", c=None):
    own = c is None; c = c or conn()
    c.execute("INSERT INTO activity(who,action,detail,created) VALUES(?,?,?,?)", (who, action, detail, time.time()))
    if own: c.commit(); c.close()
